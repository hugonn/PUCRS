import java.util.ArrayList;

// Classe que contem as tarefas e seus Periodos de Execucao
public class Execucao{
    public ArrayList<Tarefa> listaTarefas;
    public int periodoTotal;

    public Execucao(){}

    public Execucao(ArrayList<Tarefa> lst, int p){
        this.listaTarefas = lst;
        this.periodoTotal = p;
    }

    public void imprimeExecucao(){
        System.out.println("\nTarefas:");
        System.out.println("Período Total:"+ periodoTotal+"\n");
        for (Tarefa obj : listaTarefas) {
            System.out.println("Tarefa "+obj.letra+": (" + obj.computacao + "," + obj.periodo + "," + obj.deadline + ")");
        }
        System.out.println("----------------------------------------");
    }
}