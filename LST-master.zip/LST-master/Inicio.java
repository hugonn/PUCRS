import java.io.FileWriter;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.Scanner;


public class Inicio {
    

    public static void main(String[] args) {
        ArrayList<Execucao> listaExecucoes = new ArrayList<Execucao>();

        listaExecucoes = LeitorArquivo.lerArquivo();

        int menor = Integer.MAX_VALUE;
        String letraMenor = "";
        String gantt = "";
        int countPreempcao = 0;
        int posicaoEscolhido = 0;
        int posicaoAnteriorEscolhido = 0;
        String arq1 = "";

        //Cada execução, tem que ser printada
        for (Execucao obj : listaExecucoes) {
            gantt="";
            obj.imprimeExecucao();
            // Caminha pelo período total de cada execução
            for (int i =1; i<=obj.periodoTotal; i++){
                //System.out.println("\nInstante de tempo: "+i);

                // Seleciona o menor slack
                for(int j=0; j< obj.listaTarefas.size(); j++){

                    // quantidade de vezes que a tarefa foi executada deve ser menor que o número de computações. 
                    // Caso igual, tarefa ja foi executada
                    if(obj.listaTarefas.get(j).tExec < obj.listaTarefas.get(j).computacao){
                        
                        if(obj.listaTarefas.get(j).tSlack < menor){

                            menor = obj.listaTarefas.get(j).tSlack;
                            posicaoEscolhido = j;
                            letraMenor = obj.listaTarefas.get(j).letra;


                            if(i == 1){
                                posicaoAnteriorEscolhido = posicaoEscolhido;
                            }
                            //Caso ocorra preempção
                            if(posicaoAnteriorEscolhido != posicaoEscolhido){
                                if (obj.listaTarefas.get(posicaoAnteriorEscolhido).apto && (obj.listaTarefas.get(posicaoAnteriorEscolhido).tSlack > obj.listaTarefas.get(posicaoEscolhido).tSlack) ){
                                    countPreempcao++;
                                }
                                posicaoAnteriorEscolhido = posicaoEscolhido;
                            }
                            
                        }

                     // Verifica se iniciou um novo periodo para aquela tarefa voltar a estar apta para execução   
                    }else if (obj.listaTarefas.get(j).tExec == obj.listaTarefas.get(j).computacao){
                        // Quantas ativacoes que a tarefa vai ter
                        int qtdAtivacoes = obj.periodoTotal / obj.listaTarefas.get(j).periodo;
                        int c = 0;
                        int tempo =  obj.listaTarefas.get(j).periodo;
                        while(c < qtdAtivacoes){

                            // Verifica se naquele instante de tempo é o inicio de um novo periodo
                            if(i == tempo){
                                obj.listaTarefas.get(j).apto = true;
                                obj.listaTarefas.get(j).tExec = 0;
                                obj.listaTarefas.get(j).tSlack++;
                                break;
                            }
                            c++;
                            tempo += obj.listaTarefas.get(j).periodo;
                        }
                    }
                    
                
                }              
              
                // Executa a tarefa com menor slack
                obj.listaTarefas.get(posicaoEscolhido).tExec++;
                gantt += letraMenor;

                // Caso todas as execuções daquele periodo sejam feitas
                if(obj.listaTarefas.get(posicaoEscolhido).tExec == obj.listaTarefas.get(posicaoEscolhido).computacao){
                    obj.listaTarefas.get(posicaoEscolhido).apto = false;
                    obj.listaTarefas.get(posicaoEscolhido).tSlack =  obj.listaTarefas.get(posicaoEscolhido).deadline - obj.listaTarefas.get(posicaoEscolhido).computacao;
                }
                              
                for(int k = 0; k < obj.listaTarefas.size(); k++){
                    if(k != posicaoEscolhido && obj.listaTarefas.get(k).apto == true ){
                        obj.listaTarefas.get(k).tSlack--;
                    }
                }
                letraMenor=".";
                menor = Integer.MAX_VALUE;
            }
            
            String[] ganttSplit = gantt.split("");
            String letraGantt = ganttSplit[0];

            int cTrocaContexto=1;

            for (String lt : ganttSplit) {
                if(!lt.equals(letraGantt)){
                    cTrocaContexto++;
                    letraGantt = lt;
                }
                if(lt.equals("."))
                    countPreempcao++;
            }
            arq1 += gantt + "\n" + cTrocaContexto + " " + countPreempcao + "\n";

            System.out.println("Gráfico de Gantt: \n" + gantt);
            System.out.println(cTrocaContexto + " " + countPreempcao);
            System.out.println("----------------------------------------");
            countPreempcao = 0 ;
        }

        try{
            // gravar no  arquivo
            FileWriter arq = new FileWriter("./arquivos/res.out");
            PrintWriter gravarArq = new PrintWriter(arq);

            gravarArq.printf(arq1);

            arq.close();
        }catch(Exception ex){

        }
        
       
    }

}