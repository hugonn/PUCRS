import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class LeitorArquivo {

    public static ArrayList<Execucao> lerArquivo() {
        ArrayList<Tarefa> listaTarefas = new ArrayList<Tarefa>();
        ArrayList<Execucao> listaExecucoes = new ArrayList<Execucao>();
        String linha = "";
        String[] linhaDividida; 
        int numeroTarefas;
        int periodoTotal;
        boolean fimArquivo = false;
        String[] alfabeto = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","X","Y","Z"};

        System.out.printf("\nIniciando Leitura do Arquivo...\n");
        try {
            Scanner ler = new Scanner(System.in);

            System.out.println("Nome do arquivo:");
            String nome = ler.nextLine();

            FileReader arquivo = new FileReader("./arquivos/" + nome);
            BufferedReader lerArquivo = new BufferedReader(arquivo);
       
            linha = lerArquivo.readLine();
            System.out.println(linha+"\n");
            
            while(!fimArquivo){

                linhaDividida = linha.split(" ");
                // Pega o número de tarefas
                numeroTarefas = Integer.parseInt(linhaDividida[0]);
                periodoTotal = Integer.parseInt(linhaDividida[1]);

                int countLetra = 0;
                for(int i =0; i< numeroTarefas; i++){
                    Tarefa tarefa = new Tarefa();
                    linha = lerArquivo.readLine();
                    linhaDividida = linha.split(" ");
                    
                    tarefa.computacao = Integer.parseInt(linhaDividida[0]);
                    tarefa.periodo = Integer.parseInt(linhaDividida[1]);
                    tarefa.deadline = Integer.parseInt(linhaDividida[2]);
                    tarefa.tSlack = tarefa.deadline - tarefa.computacao;
                    tarefa.letra = alfabeto[countLetra];
                    countLetra++;

                    //Adiciona todas as tarefas em uma lista
                    listaTarefas.add(tarefa);
                }

                // Cria uma execucao com a lista de tarefas e o periodo total respectivo
                Execucao exe = new Execucao(listaTarefas, periodoTotal);
                listaExecucoes.add(exe);
                listaTarefas = new ArrayList<Tarefa>();
                
                linha = lerArquivo.readLine();

                if(linha.equals("")){
                    linha = lerArquivo.readLine();
                }

                if (linha.equals("0 0")){
                    System.out.println("Fim");
                    fimArquivo = true;
                  
                }
            }
            arquivo.close();

        } catch (IOException e) {
            System.err.printf("Problema ao abrir arquivo!\n", e.getMessage());
        }
        System.out.println("\nLeitura de Arquivo completa...\n");
        return listaExecucoes;
    }

}