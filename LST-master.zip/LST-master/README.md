# LST
T1 - Sistema de Tempo Real

# Arquivo
  Para mudanças de tarefas, é necessário alterar o arquivo "processos.txt" que se encontra na pasta "/arquivos"
# Rodando Sistema

./compile
