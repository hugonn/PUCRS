public class Tarefa{
    public int computacao;
    public int deadline;
    public int periodo;
    public int tSlack;
    public int tExec;
    public String letra;
    public boolean apto = true;

    Tarefa(){}

    
}