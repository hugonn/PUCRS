/*
-------- API REST --------
API referente ao projeto CMV.
    - Consultas no banco
    - Salvar Restrições
    - Envio de Alertas
*/ 
const http = require("http");
const express = require("express");
const bodyParser = require("body-parser");
const cors = require("cors");
const rotasController = require('./rotasController');


var app = express();

// var corsOptions = {
//     origin: 'http://localhost:5000/',
//     optionsSuccessStatus: 200
// }
const porta = process.env.PORT || 5001 ;

app.use(function (req, res, next) {

    // res.setHeader('Access-Control-Allow-Origin',  'http://localhost:4200');
    // // Website you wish to allow to connect
    // res.setHeader('Access-Control-Allow-Origin', 'https://hugonn.github.io/cmv-frontend/');

    var origensValidas = ['https://hugonn.github.io/cmv-dashboard/', 'https://localhost:4200'];

    var origin = req.headers.origin;
    
    if(origensValidas.indexOf(origin) > -1){
       res.setHeader('Access-Control-Allow-Origin', origin);
    }

    //res.setHeader("Content-Security-Policy: font-src 'self' data:;")
   
    // Request methods you wish to allow
    res.setHeader('Access-Control-Allow-Methods', 'GET, POST, OPTIONS, PUT, PATCH, DELETE');

    // Request headers you wish to allow
    res.setHeader('Access-Control-Allow-Headers', 'X-Requested-With,content-type');

    // Set to true if you need the website to include cookies in the requests sent
    // to the API (e.g. in case you use sessions)
    res.setHeader('Access-Control-Allow-Credentials', true);

response.setHeader(headerKey, headerVal);

    // Pass to next layer of middleware
    next();
});

app.use(bodyParser.json());

app.use(bodyParser.urlencoded({extend: true}));

app.use('/rota', rotasController);

app.listen(porta, function () {
    console.log('Servidor criado! ' + porta);
});

