var express = require("express");
var router = express.Router();
var bancoCMV = require("mysql");
var IdUltimoEvento;

// <Resumo>
// Cria conexão MySQL e usa na variavel con
// </Resumo>
var con = bancoCMV.createConnection({
    host: "192.168.15.7",
    port: 3306, 
    user: "CMV_User2",
    password: "6774Cmv"
  });

// <Resumo>
//  Cria um pool de conexão
// </Resumo>      
  con.connect(function(err) {
        
    if (err) throw err;
    console.log("Conectado ao banco!");

  });
      
// <Resumo>
//  Rotas abaixo
// </Resumo>
router.get('', (req, res) => {
    
    res.send();

    console.log("teste");
}); 


router.get('/getRestricoes', (req, res) =>{
    
    console.log("Load de restrições salvas...");
    
    con.query(`SELECT localizacao, tempo_restricao FROM Banco_CMV.Leitor where restricao = 1`, (err, result) =>{

        if(err)
            console.log("Erro na captura das restriçoes dos leitores");

        res.send(result)
    })
});

//<Resumo>
// Recupera informações para popular dropdown de localização 
//</Resumo> 
router.get('/getComodos', (req, res) => {
 

    console.log("Recuperando a localização dos leitores \n");

    con.query(`SELECT id, localizacao, mac_Address FROM Banco_CMV.Leitor`, (err, result) =>{

        if(err)
            console.log("Erro na captura da localização dos leitores");

        res.send(result)
    })
});



router.get('/getTempoNoLocal/:id', (req, res) =>{
    
    let id = req.params.id;
     console.log("Trying -> ",  id);

    con.query(`Select TIMESTAMPDIFF(MINUTE,Data_Evento,now()) as Tempo from Banco_CMV.Evento where Id = ${id}`, (err,result)=>{
        
        if(err)
        console.log(err);

        console.log(result[0].Tempo)
        res.send({Tempo:result[0].Tempo});   
 
 
    });
    
    
});



router.get('/getLocalizacao', (req, res) =>{

    
    console.log("Captura de Localização... \n");

    //<Resumo> 
    // Recupera a ultima localização da pessoa 
    //</Resumo>
    con.query(`SELECT E.ID, T.Mac_Address, P.Nome, L.Localizacao, E.Data_Evento, E.Bateria from Banco_CMV.Tag  T 
                    Left Join Banco_CMV.Pessoa P on P.ID = T.ID_Pessoa
                    Left Join Banco_CMV.Evento  E on E.ID_TAG = T.ID
                    Left Join Banco_CMV.Leitor L on L.ID = E.ID_LEITOR
                    order by E.ID DESC  `, 
    (err, result) => {
        
        if (err) throw err;

        res.send({

            IDEvento: result[0].ID,
            Nome: result[0].Nome,
            MacAddress: result[0].Mac_Address,
            Localizacao: result[0].Localizacao,
            DataEvento: result[0].Data_Evento,
            Bateria: result[0].Bateria
       
        });

    });
    
    
});


router.get('/getHistorico', (req, res) =>{

    con.query(`SELECT P.Nome , L.Localizacao, DATE_FORMAT(E.Data_Evento, "%d %M %Y - %H : %i") as Data_Evento, TIMESTAMPDIFF(MINUTE,E.Data_Evento,E.Data_Evento_Fim) as Tempo from Banco_CMV.Tag  T 
    Left Join Banco_CMV.Pessoa P on P.ID = T.ID_Pessoa
    Left Join Banco_CMV.Evento  E on E.ID_TAG = T.ID
    Left Join Banco_CMV.Leitor L on L.ID = E.ID_LEITOR
    where E.Data_Evento_Fim is not null order by E.ID DESC `, 

    (err, result) => { 

        if (err) throw err;

        res.send({ arHistorico: result});

    });

});


router.post('/salvaRestricao', (req, res) =>{

    console.log("Salvando Restricao");
    console.log(req.body.data);

 

 
        con.query(`UPDATE Banco_CMV.Leitor SET restricao = '1' , tempo_restricao = ${req.body.data.tempo} WHERE localizacao = '${req.body.data.comodo}'`, (err, result) => { 

            if (err) throw err;

            console.log("Adicionado Novo Registro");

    });
        
        
  

    

    res.send({salvo: 'OK'});
}); 


router.post('/deletaRestricao', (req, res) =>{

    console.log("Deletando Restricao");
    console.log(req.body.data);

    con.query(`UPDATE Banco_CMV.Leitor SET restricao = '0' , tempo_restricao = 0 WHERE localizacao = '${req.body.data.comodo}'`, 

    (err, result) => { 

        if (err) throw err;

        res.send({ flagOp: true}); 

    });

});

module.exports = router; 