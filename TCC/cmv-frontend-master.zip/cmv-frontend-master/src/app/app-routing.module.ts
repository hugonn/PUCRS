import { HistoricoComponent } from './pages/historico/historico.component';
import { HomeComponent } from './pages/home/home.component';
import { PaginaConfiguracaoComponent } from './pages/pagina-configuracao/pagina-configuracao.component';
import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';


const routes: Routes = [
   {path: '', component: HomeComponent},
   {path: 'pagina-configuracao', component: PaginaConfiguracaoComponent},
   {path: 'historico', component: HistoricoComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
