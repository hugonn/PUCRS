import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { MenuNavLateralComponent } from './menu-nav-lateral.component';

describe('MenuNavLateralComponent', () => {
  let component: MenuNavLateralComponent;
  let fixture: ComponentFixture<MenuNavLateralComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ MenuNavLateralComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(MenuNavLateralComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
