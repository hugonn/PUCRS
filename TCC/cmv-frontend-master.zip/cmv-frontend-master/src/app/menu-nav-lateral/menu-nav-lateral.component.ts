import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-menu-nav-lateral',
  templateUrl: './menu-nav-lateral.component.html',
  styleUrls: ['./menu-nav-lateral.component.scss']
})
export class MenuNavLateralComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
