import { MatTableDataSource } from '@angular/material';
import { Component, OnInit, AfterViewInit, KeyValueDiffers } from '@angular/core';
import { GeralService } from './../../services/geral.service';




export interface AlertaRestricaoHistorico {
  nome: string;
  comodo: string;
  tempo: number;
  data: Date;
}




@Component({
  selector: 'app-historico',
  providers: [ GeralService ],
  templateUrl: './historico.component.html',
  styleUrls: ['./historico.component.scss']
})
export class HistoricoComponent implements OnInit {

  displayedColumns = ['nome', 'comodo', 'tempo', 'data'];

  dataSource2: MatTableDataSource<AlertaRestricaoHistorico>;

  private ret : AlertaRestricaoHistorico;  

  constructor(private serviceGeral: GeralService) {
   
    this.dataSource2 = new MatTableDataSource();
  }


  ngOnInit() {


    
   
    this.populaTabelaHistorico();
    this.dataSource2.filter = '';
      
   

  }
 



  public populaTabelaHistorico() {

    this.serviceGeral.getEndpoint('/getHistorico').subscribe((data: any) => {

      console.log(data);

      console.log(data.arHistorico[1]);

      data.arHistorico.forEach(element => {
        // this.ret.nome = element.Nome;
        // this.ret.comodo = element.Localizacao;
        // this.ret.tempo = element.Data_Evento;
        // this.ret.data = element.Data_Evento_Fim;
        
        this.dataSource2.data.push({nome:element.Nome, comodo: element.Localizacao, tempo: element.Tempo, data: element.Data_Evento});
        this.dataSource2.filter = '';
      });

    });
  }
  
}


