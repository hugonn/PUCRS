import { GeralService } from './../../services/geral.service';
import { Component, OnInit } from '@angular/core';
import { trigger, state, style } from '@angular/animations';
import * as $ from 'jquery';


export interface Dados {
  dados: string;
}

class dadosEvento{
  idEvento: Number;
  nome: string;
  macAddress: string;
  localizacao: string;
  dataEvento: Date;
  bateria: string;
}

@Component({
  selector: 'app-home',
  providers: [ GeralService ],
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.scss']
})

// Summary: Componente da tela de Home
export class HomeComponent implements OnInit {

  public icone: string;
  public local: string;
  //public ArrayDados: Dados[];
  public localizacaoAtual: string;
  public idEventoAtual: Number;
  private evento: dadosEvento;
  public bateria: string;
  public tempoLocal: number;
  public contMin : number;
  public primeiroAcesso : boolean;
  


  constructor(private serviceGeral: GeralService) {
    
  }

  public imagem = 'https://media.gazetadopovo.com.br/2019/02/e27d049663d84c627d7f228524c01e16-gpMedium.jpg';

  

  // public trocaImagem() {
  //   const imagemAtual = 'https://media.gazetadopovo.com.br/2019/02/e27d049663d84c627d7f228524c01e16-gpMedium.jpg';

  //   if (this.imagem === imagemAtual) {
  //     this.icone = 'fas fa-couch';
  //     this.local = 'Sala';
  //     this.imagem = 'https://revistacarro.com.br/wp-content/uploads/2019/12/Mercedes-Benz-GLA_5.jpg';
  //   } else {
  //     this.icone = 'fas fa-bed';
  //     this.local = 'Quarto';
  //     this.imagem = 'https://media.gazetadopovo.com.br/2019/02/e27d049663d84c627d7f228524c01e16-gpMedium.jpg';
  //   }

  //   $('#animacaoMatCard').addClass('animated fadeIn');
  //   $('#animacaoIcone').addClass('animated fadeIn');

  //   setTimeout(() => {
  //     $('#animacaoIcone').removeClass('animated fadeIn');
  //     $('#animacaoMatCard').removeClass('animated fadeIn');
      
  //   }, 1000);

  // }

  ngOnInit() {

    //<RESUMO>
    //  As primeiras instruções abaixo fazem parte da inicializaçao do dashboard. Captura localizacao inicial e atualiza dados
    //</RESUMO>
    this.evento = new dadosEvento();
    this.local = " ..."
    this.imagem = "./assets/atualizando-ap.png";
    this.bateria = "..."
    this.tempoLocal;
    this.contMin = 0;
    this.primeiroAcesso = true;

    this.capturaLocalizacao();

    setTimeout(() => {
      //this.capturaLocalizacao();
      console.log(this.evento.idEvento);
      console.log(this.evento.localizacao);
    
      this.idEventoAtual = this.evento.idEvento;
      this.localizacaoAtual = this.evento.localizacao; 
      this.bateria = this.evento.bateria;
      this.atualizaLocalizacao(this.localizacaoAtual);
      this.disparaTimer(true);
     
    }, 5);

     
    
  
    
    // Summary: Intervalo de 10 segundos que verifica se há atualização de posição
    setInterval(() => {

      //this.trocaImagem();
      this.capturaLocalizacao();
      
      if(this.idEventoAtual != this.evento.idEvento){

        if(this.localizacaoAtual != this.evento.localizacao){
          
          this.localizacaoAtual = this.evento.localizacao;

          // Evento que atualiza a localização do individuo
          this.atualizaLocalizacao(this.localizacaoAtual);

          this.disparaTimer(true);


        }

        this.idEventoAtual = this.evento.idEvento;
        this.disparaTimer(false);

      }else
        this.disparaTimer(false);
      
    }, 3000);

     

  }

  
 
  // Summary: Load da localização inicial
  public capturaLocalizacao() {
    console.log("Captura de Localizaçao iniciada...\n");

    this.serviceGeral.getEndpoint('getLocalizacao').subscribe((data: any) => {

      this.evento.idEvento = data.IDEvento;
      this.evento.nome = data.Nome;
      this.evento.macAddress = data.MacAddress;
      this.evento.localizacao = data.Localizacao;
      this.evento.dataEvento = data.DataEvento;
      this.evento.bateria = data.Bateria;

      this.bateria = data.Bateria;

      if(this.primeiroAcesso){
          this.primeiroAcesso = false;
          this.serviceGeral.getEndpointSpec(`getTempoNoLocal/${data.IDEvento}`).subscribe(( data:any )=>{
          this.tempoLocal = data.Tempo;
          console.log(data.Tempo)
      
        })
      }
      

      console.log(data.Bateria);

    });
    
    console.log("Captura de Localizaçao Concluída...\n"); 
  }

  
  public atualizaLocalizacao(novaLocalizacao : String){
    console.log("Atualização de Localizaçao iniciada...\n Nova Localizacao:", novaLocalizacao);
    
    switch(novaLocalizacao){
      
      case "Quarto":{
        
        this.icone = 'fas fa-couch';
        this.local = 'Quarto - ';
        //this.imagem = 'https://www.audi.com.br/dam/nemo/br/models/Q3/2020/01_q3_designexterior.jpg?output-format=webp&downsize=1920px:*';
        this.imagem = "./assets/imgQuarto1.png"; 
        this.ativaAnimacao();

        break;
      }
      case "Quarto2":{
        
        this.icone = 'fas fa-bed';
        this.local = 'Quarto 2 - ';
        //this.imagem = 'https://abrilquatrorodas.files.wordpress.com/2019/09/bmw_320d_sport_line_30_04f9031408af05e8.jpg?quality=70&strip=info';
        this.imagem = "./assets/imgQuarto2.png"; 
        this.ativaAnimacao();

        break;
      }
      case "Sala":{

        this.icone = 'fas fa-couch';
        this.local = 'Sala - ';
        //this.imagem = 'https://s2.glbimg.com/N4VVaApD5VG_3Y13TS67tN0ZDcM=/620x413/e.glbimg.com/og/ed/f/original/2019/03/07/jeep_compass_plug-in_hybrid.jpeg';
        this.imagem = "./assets/imgSala.png"; 
        this.ativaAnimacao();

        break;

      }
      case "Banheiro":{

        this.icone = 'fas fa-toilet-paper';
        this.local = 'Banheiro - ';
        //this.imagem = 'https://s2.glbimg.com/UPmcqDBZsoLo4RjBap1KGSzAj3I=/620x413/e.glbimg.com/og/ed/f/original/2020/04/16/nivus-frente-branco_1.jpg';
        this.imagem = "./assets/imgBanheiro.png"; 
        this.ativaAnimacao();

        break;

      }
      case "Cozinha":{

        this.icone = 'fas fa-cookie-bite';
        this.local = 'Cozinha - ';
        //this.imagem = 'https://abrilquatrorodas.files.wordpress.com/2019/03/jeep-renegade-phev.jpg?quality=70&strip=info';
        this.imagem = "./assets/imgCozinha.png"; 
        this.ativaAnimacao(); 
        break;
      }
    }
  }

  public ativaAnimacao(){
    $('#animacaoMatCard').addClass('animated fadeIn');
    $('#animacaoIcone').addClass('animated fadeIn');

     setTimeout(() => {
       $('#animacaoIcone').removeClass('animated fadeIn');
       $('#animacaoMatCard').removeClass('animated fadeIn');
      
     }, 1000);
  }

  //<Resumo>
  // Funcao de disparo de tempo. Caso nao mude de localizacao, contador de minuto segue somando até chegar 1 minuto. 
  // chegando a 1 minuto atribui + 1 no tempoLocal
  // Caso mude de posicao, contador de minuto é zerado e tempoLocal recebe novo valor de tempo do banco
  //</Resumo>
  public disparaTimer(mudou:boolean){
    console.log(" Disparando Timer ");

    if(!mudou){

      if(this.contMin == 60){
        this.contMin = 0;
        this.tempoLocal++;
      }else{
        this.contMin = this.contMin + 10;

        console.log("Add 10 ao contMin", this.contMin);
      }

      console.log("Nao mudou de posicao");
    }
    else{

      mudou = false;

      if(!this.primeiroAcesso)
         this.tempoLocal = 0;
      
      

    }
  }

  
}
