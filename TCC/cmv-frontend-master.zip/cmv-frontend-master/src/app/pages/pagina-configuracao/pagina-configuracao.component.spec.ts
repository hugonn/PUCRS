import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { PaginaConfiguracaoComponent } from './pagina-configuracao.component';

describe('PaginaConfiguracaoComponent', () => {
  let component: PaginaConfiguracaoComponent;
  let fixture: ComponentFixture<PaginaConfiguracaoComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ PaginaConfiguracaoComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(PaginaConfiguracaoComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
