import { GeralService } from './../../services/geral.service';
import { Component, OnInit, ViewChild } from '@angular/core';
import { MatTableDataSource } from '@angular/material';
import { FormGroup, FormBuilder } from '@angular/forms';
import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';



@Component({
  selector: 'app-pagina-configuracao',
  providers: [ GeralService ],
  templateUrl: './pagina-configuracao.component.html',
  styleUrls: ['./pagina-configuracao.component.scss']
})



export class PaginaConfiguracaoComponent implements OnInit {

  displayedColumns = ['comodo', 'tempo', 'acoes'];
  dataSource: MatTableDataSource<AlertaRestricao>;

  // Restricoes que não foram adicionadas no banco ainda
  listaRestricoesAdd: AlertaRestricao[];
  // Restricoes vindas do banco de dados
  listaRestricoesBanco: AlertaRestricao[];
  public comodos: any;
  public locais: any;
  public local: string;
  public currentComodo : leitor;

  constructor(private service: GeralService) {
    this.dataSource = new MatTableDataSource();
    this.listaRestricoesAdd = [];
    this.listaRestricoesBanco = [];
  } 

  ngOnInit() {

    this.loadDropDownComodos();

    // console.log("COMODO ANTES DO TIMEOUT -------> ", this.comodos);

    // setTimeout(() => {
      
    //   console.log("Comodos TIMEOUT ---->", this.comodos);

    // }, 200);


    this.loadRestricoesAtivas();
  }

  public loadDropDownComodos(){
      this.service.getEndpoint('getComodos').subscribe((data: any) => {
        this.comodos =  data;
        this.locais = data;

      })
  }
  public async loadRestricoesAtivas() {

    await this.service.getEndpoint('getRestricoes').subscribe((data2: any) => {
      // console.log('data2', data2);

      if(data2)
        data2.forEach(element => {
          console.log(element.localizacao);
          this.addAlerta(element, element.tempo_restricao, true);
        });

    });
  }

   
  // add na tabela de restricoes
  addAlerta(com, tem, flagBanco = false) {

    if (!tem) {
      alert ('É necessário preencher o tempo estimado!');
    } else {

      
      this.dataSource.data.push({comodo: com.localizacao, tempo: tem});
      this.dataSource.filter = '';
      
      if(flagBanco == false)
        this.listaRestricoesAdd.push({comodo: com.localizacao, tempo: tem});
      else
        this.listaRestricoesBanco.push({comodo: com.localizacao, tempo: tem});
      
    }
  }


  salvarRestricoes() {

    if (this.listaRestricoesAdd.length > 0) {
      alert('Adiciona restricao');

      this.listaRestricoesAdd.forEach(element => {
        
        this.listaRestricoesBanco.push(element);

        this.service.postEndpoint("salvaRestricao", element).subscribe(data => {
            
        });  


      });
      this.listaRestricoesAdd = [];

      console.log(this.listaRestricoesAdd);
    } else {
      alert('Registre uma nova Restrição');

    }

  }

  // Remove da tela e da lista de adiçao
  deletarRestricao(data) {

    console.log("Deletando Restricao ->")
    console.log(this.listaRestricoesBanco)

    this.dataSource.data.forEach((element, index) => {
      
      if (element.comodo === data.comodo) {
        this.dataSource.data.splice(index, 1);

      }

    });

    // Procura se o comodo adicionado é novo ou ja estava cadastrado
    if(this.listaRestricoesAdd.length > 0 ){
      
      console.log("Deletando comodo adicionado recentemente");

      this.listaRestricoesAdd.forEach((element, index) => {

        if (element.comodo === data.comodo) {
          this.listaRestricoesAdd.splice(index, 1);         
        }
        
      });

    }
    
    if(this.listaRestricoesBanco.length > 0){

      console.log("Deletando comodo recuperado do banco");
      
      this.listaRestricoesBanco.forEach((element, index) => {

        if (element.comodo === data.comodo) {

          this.listaRestricoesBanco.splice(index, 1); 
          this.service.postEndpoint("deletaRestricao", element).subscribe(data => {
            
           });      

        }

      });
    }

    this.dataSource.filter = '';
  }


}

export interface AlertaRestricao {
  comodo: string;
  tempo: number;
}

export interface leitor{
  id: number;
  localizacao:string;

}
