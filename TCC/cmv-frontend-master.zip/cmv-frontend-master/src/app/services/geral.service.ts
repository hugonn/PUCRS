import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})


export class GeralService {

  readonly url = 'http://localhost:5001/rota';//'https://projetocmvbackend.herokuapp.com/rota'

  // Summary: Construtor do serviço
  // Params: criação http para requisições
  constructor(private http: HttpClient) {}

  

  // Summary: Chama método do backend de forma Genérica
  // Params: url Endpoint
  // return: json
  public getEndpoint = (endpoint, dados?) => this.http.get(`${this.url}/${endpoint}`);
  public getEndpointSpec = (endpoint) => this.http.get(`${this.url}/${endpoint}`);
  public postEndpoint = (endpoint, dados) => this.http.post(`${this.url}/${endpoint}`,{ data:dados }); 
}
