import java.rmi.Naming;
import java.rmi.RemoteException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.*;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;


public class peerClient{

    serverInterface inter = null;

    public byte[] createChecksum(String filename) throws Exception {
        InputStream fis =  new FileInputStream(filename);
 
        byte[] buffer = new byte[1024];
        MessageDigest complete = MessageDigest.getInstance("MD5");
        int numRead;
 
        do {
            numRead = fis.read(buffer);
            if (numRead > 0) {
                complete.update(buffer, 0, numRead);
            }
        } while (numRead != -1);
 
        fis.close();
        System.out.println(complete.digest());
        return complete.digest();
    }

    // public byte[] calcHash(FileReader obj) {
    //     MessageDigest algorithm = MessageDigest.getInstance("MD5");
    //     byte messageDigest[] = algorithm.digest(obj.getBytes());
                    
    //     System.out.println(messageDigest);
    //     return messageDigest;
    // }

    public ArrayList<byte[]> readFiles(String enderecoArquivos) {
        BufferedReader objReader = null;
        String strCurrentLine;
        File files[];
        File directory = new File(enderecoArquivos);
        System.out.println(directory);
        ArrayList<byte[]> hashList = new ArrayList<byte[]>();
        files = directory.listFiles();
        for(int i = 0; i < files.length; i++) {
            try {
                objReader = new BufferedReader(new FileReader(files[i]));
                FileReader fileR = new FileReader(files[i]);
                try {
                    byte[] hashFile = this.createChecksum(files[i].getName());
                    hashList.add(hashFile);
                    System.out.println(hashFile);
                } catch(Exception e2){

                }
                
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
        
                try {
                    if (objReader != null)
                    objReader.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
        }
        return hashList;
    }

    public peerClient(String enderecoServidor, String enderecoArquivos) {
        
        String remoteHostName = enderecoServidor;
        String connectLocation = "//" + remoteHostName + "/op";
        String clientName = "";
        String clientIp = "";
        ArrayList<byte[]> hash = new ArrayList<byte[]>();
        
        //Alterar para saber a pasta a ser compartilhada
        hash = this.readFiles(enderecoArquivos);

        //serverInterface inter = null;
        try{
            clientName = InetAddress.getLocalHost().getHostName();
            clientIp = InetAddress.getLocalHost().getHostAddress();
            System.out.println(InetAddress.getLocalHost().getHostAddress());
        } catch(UnknownHostException e) {
            System.out.println ("Falhou ao buscar o ip ");
        }
        
        try{
            System.out.println("Conectando no cliente em : " + connectLocation);
			inter = (serverInterface) Naming.lookup(connectLocation);
        }catch(Exception e){
            System.out.println ("Criação de peer falhou: ");
			e.printStackTrace();
        }
        // Por enquanto cria na força bruta o peer com quaisquer valores
        try {
			inter.registraPeer(clientName, clientIp, hash);
		} catch (RemoteException e) {
			e.printStackTrace();
		}
    }

    public ArrayList<peerInfo> listaRecursos(){
       
        try{
            return inter.getRecursos();
        }catch (RemoteException e) {
			e.printStackTrace();
        }
        return null;

    }






    
}