import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Scanner;
import java.lang.Thread;
import java.lang.InterruptedException;

// ps -ef | grep java
// kill rmi java

class p2p {
    
	public static void main (String[] argv) {
        
        if(argv[0].equals("server")){
            try {
                java.rmi.registry.LocateRegistry.createRegistry(1099);
                System.out.println("RMI registry ready.");			
            } catch (RemoteException e) {
                System.out.println("RMI registry already running.");			
            }
            try{
                Naming.rebind("op", new operacoesServer());
                System.out.println("Server de OP pronto");
                
            }catch (Exception e) {
                System.out.println("Server de OP falhou: " + e);
            }

        }else{
            // Lógica do peer
            Scanner scanner = new Scanner(System.in);
            peerClient pc = new peerClient(argv[0], argv[1]);
            Boolean working = true;
            int op = 0;
            while(working) {
                System.out.println("Escolha uma opção:");
                System.out.println("1 - Listar Recursos.");
                System.out.println("2 - Solicitar recurso.");
                System.out.println("3 - Sair.");
                op = scanner.nextInt();
                switch(op) {
                    case 1: 
                        ArrayList<peerInfo> list = pc.listaRecursos();
                        // Lista os recursos
                        for (peerInfo var : list) {
                            System.out.println("\nNome do Hospedeiro: " + var.name);
                            System.out.println("IP: " + var.ip);
                            System.out.println("Hash Arquivos:" + var.files +"\n");
                        }
                        break;
                    case 2:
                        // faz solicitação 
                        Boolean selecionando = true;
                        System.out.println("Identifique o recurso requerido:");
                        while(selecionando) {
                            String recurso = scanner.nextLine();
                            selecionando = false;
                        }
                        // try { Thread.sleep (1000); } catch (InterruptedException ex) {}
                        // executa recurso
                        break;

                    case 3: working = false;
                    
                    default: break;
                }
            }
        }
		
		
	}
}
