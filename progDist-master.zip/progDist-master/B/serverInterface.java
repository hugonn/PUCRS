import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;


// Cliente chama os métodos dessa Interface aqui
public interface serverInterface extends Remote {
	
	//public void say() throws RemoteException;
	public void registraPeer(String name, String ip, ArrayList<byte[]> hash) throws RemoteException; // Registrar peer e passar endereço do local
	public ArrayList<peerInfo> getRecursos() throws RemoteException;

}


