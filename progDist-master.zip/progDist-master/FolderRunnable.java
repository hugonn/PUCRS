public class FolderRunnable implements Runnable{

    public String myFileFolder = "";

    public FolderRunnable(String myFileFolder) {
        this.myFileFolder = myFileFolder;

    }
    public void run() {
        try {
            while(true){
                System.out.println("Cria thread");
                SocketProject sp = new SocketProject();
                sp.workAsServer(this.myFileFolder);
                System.out.println("Fecha Socket");
            }
            //while(true) {
            //    System.out.println("socket 2");
            //}                
        } catch(Exception e) {}
        
    }
}