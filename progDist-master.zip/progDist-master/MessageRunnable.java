public class MessageRunnable implements Runnable{

    public String myFileFolder = "";
    public int myPort;

    public MessageRunnable(String myFileFolder, int myPort) {
        this.myFileFolder = myFileFolder;
        this.myPort = myPort;
    }

    public void run() {
        try {
            while(true){
                System.out.println("Cria thread");
                SocketProject sp = new SocketProject();
                sp.whatDoYouWant(this.myFileFolder, this.myPort);
                System.out.println("Fecha Socket");
            }
            //while(true) {
            //    System.out.println("socket 2");
            //}                
        } catch(Exception e) {}
        
    }

}