# progDist

Compilar projeto:
    ./compile
Limpar projeto:
    ./clean
Iniciar como servidor:
    java p2p server <--Ip do servidor-->
Iniciar como cliente:
    java p2p <--ip servidor--> <--pasta distribuida--> <--meu ip--> <--Porta que vai receber-->
