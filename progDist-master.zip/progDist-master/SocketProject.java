import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;
import java.io.PrintStream;
import java.net.UnknownHostException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.DataOutputStream;
import java.io.FileOutputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedInputStream;
import java.io.*;
import java.io.File;
import java.io.FileReader;

public class SocketProject{

    private int port = 1098;
    private String type;

    /*
    WorkAsServer é um socket iniciado quando o peer se registra no servidor
    responsável por receber os arquivos vindo de outros peers
    */
    public void workAsServer(String folderName) throws IOException {
        ServerSocket server = new ServerSocket(this.port);
        System.out.println("Criou socket como servidor");
        Socket cliente = server.accept();
        System.out.println("Arquivo recebido");
        InputStream in = null;
        OutputStream out = null;

        in = cliente.getInputStream();
        System.out.println(in);
        out = new FileOutputStream("./"+ folderName + "/file.md");
        System.out.println(out);
        
        byte[] bytes = new byte[16*1024];
        System.out.println("Arquivo recebido");
        int count;
        while ((count = in.read(bytes)) > 0) {
            System.out.println(bytes);
            out.write(bytes, 0, count);
        }

        out.close();
        in.close();
        cliente.close();
        server.close();
        System.out.println("Arquivo recebido");
    }
    /*
    workAsClient responsável por enviar o arquivo requerido por outro peer
    */
    public void workAsClient(String fileUrl, String ip) throws UnknownHostException, IOException {
        Socket socket = new Socket(ip, this.port);
        System.out.println("O cliente se conectou ao servidor!");
        System.out.println(fileUrl);
        System.out.println(ip);
        File file = new File(fileUrl);
        // Get the size of the file
        long length = file.length();
        byte[] bytes = new byte[16 * 1024];
        InputStream in = new FileInputStream(file);
        OutputStream out = socket.getOutputStream();

        int count;
        while ((count = in.read(bytes)) > 0) {
            System.out.println(bytes + "\n");
            out.write(bytes, 0, count);
        }

        out.close();
        in.close();
        socket.close();
    }
    /*
    whatDoYouWant iniciado junto ao registro no servidor
    recebe os pedidos de outros peers para fazer o envio
    */
    public void whatDoYouWant(String folderName, int myPort) throws UnknownHostException, IOException{
        ServerSocket server = new ServerSocket(myPort);
        Socket socket = server.accept();
        System.out.println("Connection from " + socket + "!");

        // get the input stream from the connected socket
        InputStream inputStream = socket.getInputStream();
        // create a DataInputStream so we can read data from it.
        DataInputStream dataInputStream = new DataInputStream(inputStream);

        // read the message from the socket
        String message = dataInputStream.readUTF();
        System.out.println("The message sent from the socket was: " + socket.getInetAddress().toString());
        String ip = socket.getInetAddress().toString();
        System.out.println("The message sent from the socket was: " + ip.replaceFirst("/", ""));
        SocketProject takeThisShit = new SocketProject();
        
        takeThisShit.workAsClient("./" + folderName+ "/" + message, (ip.replaceFirst("/", "")));

        System.out.println("Closing sockets.");
        server.close();
        socket.close();
    }
    /*
    gimmeYourButty faz pedido do arquivo requerido para outro peer
    */
    public void gimmeYourButty(String message, String ip, int originPort) throws UnknownHostException, IOException{
        try{
            Socket socket = new Socket(ip, originPort);
            OutputStream outputStream = socket.getOutputStream();
            DataOutputStream dataOutputStream = new DataOutputStream(outputStream);

            // write the message we want to send
            dataOutputStream.writeUTF(message);
            dataOutputStream.flush(); // send the message
            dataOutputStream.close(); // close the output stream when we're done.

            System.out.println("Closing socket and terminating program.");
            socket.close();

        }catch(Exception e){
            System.out.println(e.getMessage());
        }
        
    }
}