import java.util.HashMap;
import java.util.concurrent.Semaphore;
import java.io.Serializable;
import java.nio.charset.Charset;
import java.rmi.RemoteException;
import java.rmi.server.UnicastRemoteObject;
import java.util.ArrayList;

// Classe que possui a implementação da serverInterface
public class operacoesServer extends UnicastRemoteObject implements serverInterface, Serializable {
	private static final long serialVersionUID = 7896795898928782846L;
	private static ArrayList<peerInfo> listaRecursos = new ArrayList<peerInfo>();
	private Semaphore semaforo = new Semaphore(1);

	//Construtor das operações
	public operacoesServer() throws RemoteException{
		new Thread(this.operacaoHeartbeat).start();	
	};

	//Registra peer no server 
	public void registraPeer(String name, String ip, HashMap<String, byte[]> hash, int myPort){
		peerInfo info = new peerInfo(name, ip, hash, myPort);
		
		listaRecursos.add(info);
		System.out.println("Peer adicionado com sucesso");
		System.out.println(info.name);
		System.out.println(info.ip);
		System.out.println(info.files.toString());
	
	}
	 
	public ArrayList<peerInfo> getRecursos(){		
		return this.listaRecursos;
	}


	public void toVivo(String ip){
		try{
			semaforo.acquire();
			System.out.println("Chamada Op to vivo");
			for (peerInfo obj : listaRecursos) {
				if(obj.heartBeatSign < 2)
					obj.heartBeatSign++;
			}

		}catch(Exception ex){

		}
		finally{
			semaforo.release();
		}
	}

	// Remove da lista de recursos caso heartbeatsign == 0
	public Runnable operacaoHeartbeat = new Runnable(){
              
		public void run() {

			while(true){
				System.out.println(("Chamada Op Heartbeat"));  
				
				try{
					Thread.sleep(5000);
				}catch(InterruptedException ex){

				}
				ArrayList <Integer> listaRemove = new ArrayList<Integer>();
				
					try{
						semaforo.acquire();
						for (int i =0; i< listaRecursos.size(); i++ ) {
							if(listaRecursos.get(i).heartBeatSign == 0){

								listaRemove.add(i);
							}else{
								listaRecursos.get(i).heartBeatSign--;
							}
						}
						semaforo.release();
					}catch(InterruptedException e){
						System.out.println(e.getMessage());
					}
					catch(Exception ex){
						System.out.println(ex.getMessage());
					}finally{

						try{
							semaforo.acquire();

						
						if(listaRemove.size() > 0) {

						
						
						
							for (int index : listaRemove) {
								listaRecursos.remove(index);
							}

						} 
							semaforo.release();
						}
						catch(InterruptedException e){

						}
						
					}
					
				
			}

		}
			
	};

	public void sairGraciosamente(String ip) {
		try{
			semaforo.acquire();
			for (int i =0; i< listaRecursos.size(); i++ ) {
				if(listaRecursos.get(i).ip.equals(ip)) {
					listaRecursos.remove(i);
				}
			}
		} catch (Exception e) {

		} finally {
			semaforo.release();
		}
	}

	// public String pegaHash(String nome){
	// 	ArrayList<peerInfo> listaR = getRecursos();

	// 	for(peerInfo obj : listaR){
	// 		for(String nomeFile : obj.files.keySet()){
	// 			if(nome.equals(nomeFile)){
	// 				String hash = obj.files.get(nome);
	// 				return hash;
	// 			}
	// 		}
	// 	}

	// }
}