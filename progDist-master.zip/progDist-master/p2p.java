import java.rmi.Naming;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.Scanner;
import java.io.IOException;

import javax.management.remote.rmi.RMIConnector;

import com.sun.nio.sctp.Notification;

import java.lang.Thread;
import java.lang.InterruptedException;

// ps -ef | grep java
// kill rmi java

class p2p {
    
	public static void main (String[] argv) {
        
        if(argv[0].equals("server")){
            try {
                java.rmi.registry.LocateRegistry.createRegistry(1099);
                System.setProperty("java.rmi.server.hostname",argv[1]);
                System.out.println("RMI registry ready.");			
            } catch (RemoteException e) {
                System.out.println("RMI registry already running.");			
            }
            try{
                Naming.rebind("op", new operacoesServer());
                System.out.println("Server de OP pronto");
                
            }catch (Exception e) {
                System.out.println("Server de OP falhou: " + e);
            }

        }else{
            // Lógica do peer
            Scanner scanner = new Scanner(System.in);
            Scanner scanner2 = new Scanner(System.in);
            Scanner scanner3 = new Scanner(System.in);
            Scanner scanner4 = new Scanner(System.in);
            peerClient pc = new peerClient(argv[0], argv[1], argv[2], argv[3]);
            String ipp = argv[2];
            String myPortString = argv[3];
            Integer myPort = Integer.valueOf(myPortString);
            Boolean working = true;
            
            int op = 0;
            do  {
                System.out.println("Escolha uma opção:");
                System.out.println("1 - Listar Recursos.");
                System.out.println("2 - Solicitar recurso.");
                System.out.println("3 - Sair.");
                op = scanner.nextInt();
                switch(op) {
                    case 1: 
                        ArrayList<peerInfo> list = pc.listaRecursos();
                        // Lista os recursos
                        for (peerInfo var : list) {
                            System.out.println("\nNome do Hospedeiro: " + var.name);
                            System.out.println("IP: " + var.ip);
                            System.out.println("Hash Arquivos:" + var.files +"\n");
                            System.out.println("Porta para conectar:" + var.myPort +"\n");
                            // precisa guardar essa lista em algum lugar, talvez peerClient seja o melhor lugar
                        }
                        break;
                    case 2: 
                        Boolean selecionando = true;
                        System.out.println("Identifique o recurso requerido:");
                        String recurso = scanner2.nextLine();
                        System.out.println("Identifique ip do peer:");    
                        String ip = scanner3.nextLine(); 
                        System.out.println("Identifique a porta socket do peer:");    
                        int socketPort = scanner4.nextInt();   
                        try {
                            pc.sendMessage(recurso, ip, socketPort); 
                        } catch (IOException e) {}
                                          
                        break;

                    case 3: try {
                        pc.inter.sairGraciosamente(ipp);
                        System.exit(0);
                        } catch (Exception e) {}  break;
                    // testando o envio de arquivos
                    // case 4: try {pc.send("C:\\Users\\Bruno Kieling\\Documents\\git\\progDist\\README.md", "127.0.0.1");} catch(Exception e) {} break;
                    // testando o pedido de arquivo
                    // case 5: try {pc.sendMessage("tst", "127.0.0.1");} catch(Exception e2) {} break;
                    default: break;
                } 
            } while(working);
        }
		
		
    }
    public void test() {
        
    }
}
