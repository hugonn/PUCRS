import java.rmi.Naming;
import java.rmi.RemoteException;
import java.net.Inet4Address;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.*;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.security.MessageDigest;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.HashMap;
import java.util.Map;


public class peerClient{

    public String folderName = "";
    public String meuIP = "";
    serverInterface inter = null;
    // Calcula hash dos arquivos
    public byte[] createChecksum(String filename) throws Exception {
        InputStream fis =  new FileInputStream(filename);
 
        byte[] buffer = new byte[1024];
        MessageDigest complete = MessageDigest.getInstance("MD5");
        int numRead;
 
        do {
            numRead = fis.read(buffer);
            if (numRead > 0) {
                complete.update(buffer, 0, numRead);
            }
        } while (numRead != -1);
 
        fis.close();
        System.out.println(complete.digest());
        return complete.digest();
    }

    // Acessa os arquivos da pasta compartilhada
    public HashMap<String, byte[]> readFiles(String enderecoArquivos) {
        BufferedReader objReader = null;
        String strCurrentLine;
        File files[];
        File directory = new File(enderecoArquivos);
        System.out.println(directory);
        HashMap<String, byte[]> hashMap = new HashMap<String, byte[]>();
        files = directory.listFiles();
       
        for(int i = 0; i < files.length; i++) {
            try {
                // AQUI DA PRA PEGAR O NOME DO ARQUIVO System.out.println("NOME ARQUIVO ->" + files[i]);
                objReader = new BufferedReader(new FileReader(files[i]));
                FileReader fileR = new FileReader(files[i]);
                try {
                    byte[] hashFile = this.createChecksum(files[i].getName());
                    hashMap.put(files[i].toString(), hashFile);
                    System.out.println(hashFile);
                } catch(Exception e2){

                }
                
                } catch (IOException e) {
                    e.printStackTrace();
                } finally {
        
                try {
                    if (objReader != null)
                    objReader.close();
                    } catch (IOException ex) {
                        ex.printStackTrace();
                    }
                }
        }
        return hashMap;
    }

    public peerClient(String enderecoServidor, String enderecoArquivos, String meuIP, String minhaPort) {
        Integer intPort = Integer.parseInt(minhaPort);
        String remoteHostName = enderecoServidor;
        String connectLocation = "//" + remoteHostName + "/op";
        String clientName = "";
        String clientIp = "";
        this.meuIP = meuIP;
        this.folderName = enderecoArquivos;
        HashMap<String, byte[]> hash = new HashMap<String, byte[]>();
        Runnable receive = new FolderRunnable(enderecoArquivos);
        new Thread(receive).start();
        Runnable receiveMessage = new MessageRunnable(enderecoArquivos, intPort);
        new Thread(receiveMessage).start();
       
        //Alterar para saber a pasta a ser compartilhada
        hash = this.readFiles(enderecoArquivos);

        //serverInterface inter = null;
        try{
            clientName = InetAddress.getLocalHost().getHostName();
            clientIp = this.meuIP;// InetAddress.getLocalHost().getHostAddress();
            System.out.println(InetAddress.getLocalHost().getHostAddress());
        } catch(UnknownHostException e) {
            System.out.println ("Falhou ao buscar o ip ");
        }
        
        try{
            System.out.println("Conectando no cliente em : " + connectLocation);
			inter = (serverInterface) Naming.lookup(connectLocation);
        }catch(Exception e){
            System.out.println ("Criação de peer falhou: ");
			e.printStackTrace();
        }

        try {
            inter.registraPeer(clientName, clientIp, hash, intPort);
            Runnable toVivo = new toVivo(clientIp,inter);
            new Thread(toVivo).start();	

		} catch (RemoteException e) {
			e.printStackTrace();
		}
    }

    // Lista os recursos disponíveis chamando procedimento remoto
    public ArrayList<peerInfo> listaRecursos(){
       
        try{
            return inter.getRecursos();
        }catch (RemoteException e) {
			e.printStackTrace();
        }
        return null;

    }
 
    /*
    Send responsável por enviar o arquivo para outro peer
     */
    public void send(String fileUrl, String ip) throws IOException{
        try {
            SocketProject sp = new SocketProject();
            sp.workAsClient(fileUrl, ip);
        } catch(IOException e) {}
    }
    /*
    SendMessage responsável por fazer o pedido do arquivo para outro peer
     */
    public void sendMessage(String messsage, String ip, int myPort) throws IOException{
        try {
            SocketProject sp = new SocketProject();
            sp.gimmeYourButty(messsage, ip, myPort);
        } catch(IOException e) {}
    }
    
}