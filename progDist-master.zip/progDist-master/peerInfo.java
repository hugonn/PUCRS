import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

// Classe que conterá o ip e hash do peer.
// Uma lista vai guardar as informações do peer no server
public class peerInfo implements Serializable{
    String ip;
    String name;
    int myPort;
    int heartBeatSign;
    HashMap<String, byte[]> files = new HashMap<String, byte[]>();

    peerInfo(String name, String ip, HashMap<String, byte[]> hashs, int myPort){
        this.ip = ip;
        this.name = name;
        this.files = hashs;
        this.myPort = myPort;
        this.heartBeatSign = 2;
    }
}
