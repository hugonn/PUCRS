import java.rmi.Remote;
import java.rmi.RemoteException;
import java.util.ArrayList;
import java.util.HashMap;



// Cliente chama os métodos dessa Interface aqui
public interface serverInterface extends Remote {
	
	//public void say() throws RemoteException;
	public void registraPeer(String name, String ip, HashMap<String, byte[]> hash, int myPort) throws RemoteException; // Registrar peer e passar endereço do local
	public ArrayList<peerInfo> getRecursos() throws RemoteException;
	public void toVivo(String ip) throws RemoteException;
	public void sairGraciosamente(String ip) throws RemoteException;
	//public String pegaHash(String nomeArquivo) throws RemoteException;

}


