

public class toVivo implements Runnable{

    public String meuIp = "";
    serverInterface inter = null;

    public toVivo(String myIp, serverInterface inter) {
        this.inter = inter;
        this.meuIp = myIp;
    }
    public void run() {
                    try{
                        while(true){  
                            inter.toVivo(this.meuIp);
                            Thread.sleep(2500);
                        }
                    }catch(InterruptedException e){

                    }catch(Exception ex){
                        System.out.println(ex.getMessage());
                    }
                }

}