
public enum Algoritmo {
	LRU,
	ALEATORIO
}
