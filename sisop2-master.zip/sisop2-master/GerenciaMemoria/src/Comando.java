
public enum Comando {
	ACESSAR,
	ALOCAR,
	TERMINAR
}
