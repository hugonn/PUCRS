
public class Main {

	public static void main(String[] args) {
		
		Gerador g = new Gerador(5);
		
		g.gerar();
		g.executar();
		
	}
	
}
